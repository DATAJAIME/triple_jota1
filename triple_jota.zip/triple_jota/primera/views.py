from django.shortcuts import render
from primera.models import Project

def project_index(request):
    primera = Project.objects.all()
    context = {
        'primera': primera
    }
    return render(request, 'project_index.html', context)


def papa(request):
    primera = Project.objects.all()
    context = {
        'primera': primera
    }
    return render(request, 'papa.html', context)