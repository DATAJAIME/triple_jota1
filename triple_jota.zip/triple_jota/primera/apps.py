from django.apps import AppConfig


class PrimeraConfig(AppConfig):
    name = 'primera'
